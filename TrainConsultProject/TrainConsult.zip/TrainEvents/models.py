from django.db import models

# Create your models here.

class Events(models.Model):
    event_id = models.CharField(max_length=100)
    event_name = models.CharField(max_length=100)
    event_date = models.DateField()
    event_venue = models.CharField(max_length=100)
    event_time = models.CharField(max_length=100)
    event_image = models.ImageField(upload_to="pictures")

    def __str__(self):
        return self.event_name

class OrgBookEvents(models.Model):

    PAYMENT_CHOICES = (
        ('mpesa', 'M-Pesa'),
        ('visa', 'Visa')
    )

    EVENTS = (
        ('choose', 'Choose Event'),
        ('women-led', '1ST WOMEN LEAD CONFERENCE'),
    )

    MODE_OF_ATTENDANCE = (
        ('physical', 'Physical'),
        ('virtual', 'Virtual'),
        ('student', 'Student')
    )

    event = models.CharField(max_length=100, choices=EVENTS)
    first_name = models.CharField(max_length=100)
    middle_name = models.CharField(max_length=100, null=True)
    last_name = models.CharField(max_length=100)
    email_address = models.EmailField(max_length=100)
    attendance_mode = models.CharField(max_length=100, choices=MODE_OF_ATTENDANCE)
    phone_number = models.CharField(max_length=15, null=True)
    # # booking_amount = models.PositiveIntegerField()
    # mode_of_payment = models.CharField(max_length=10, choices=PAYMENT_CHOICES)
    # transaction_id = models.CharField(max_length=20)
    booking_status = models.CharField(max_length=20, default="Not Approved")

    def __str__(self):
        return self.full_names

