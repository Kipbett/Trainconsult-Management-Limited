from django.contrib import admin

# Register your models here.
from .models import Events, OrgBookEvents

class BookEventsAdmin(admin.ModelAdmin):
    list_display = (
        "first_name",
        "last_name",
        "middle_name",
        "event",
        "attendance_mode",
        "email_address",
    )
    list_filter = ("first_name", "last_name", "attendance_mode")
    search_fields = ("full_names",)

admin.site.register(Events)
admin.site.register(OrgBookEvents, BookEventsAdmin)
