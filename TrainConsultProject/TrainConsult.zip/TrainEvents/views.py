import json
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from .forms import OrgBookingForm
from django_daraja.mpesa.core import MpesaClient
from django.contrib import messages

from .models import OrgBookEvents
from Utils.pesapalpayment import submit_order_request

def book_event(request):
    if request.method == 'POST':
        form = OrgBookingForm(request.POST)
        if form.is_valid():
            cl = MpesaClient()
            phone_number = request.POST['phone_number']
            attendance = request.POST['attendance_mode']
            email_address = request.POST['email_address']
            first_name = request.POST['first_name']
            last_name = request.POST['last_name']
            middle_name = request.POST['middle_name']
            if attendance == "physical":
                amount = 1
            elif attendance == "virtual":
                amount = 1
            elif attendance == "student":
                amount = 1
            submit_order_request(amount, '+254'+phone_number[1:], email_address, first_name, last_name, middle_name)
            submit_order = submit_order_request(amount, phone_number, email_address, first_name, last_name, middle_name)
            j_response = (
                submit_order.json()
            )
            redirect_url = j_response['redirect_url']
            form.save()
            messages.success(request, "Data Saved Successfully.")
            return HttpResponseRedirect(redirect_url)
    else:
        form = OrgBookingForm()
    return render(request, 'booking.html', {'form': form,})

def show_bookings(request):
    bookings = OrgBookEvents.objects.all()
    return render(request, 'bookings.html', {'bookings': bookings})


