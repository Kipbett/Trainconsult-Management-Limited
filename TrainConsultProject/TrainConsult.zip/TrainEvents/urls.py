from django.urls import path
from . import views

urlpatterns = [
    path('', views.book_event),
    path('bookings/', views.show_bookings, name='bookings'),
    # path('confirm-payment/', views.confirm_payment, name='confirm-payment'),
]