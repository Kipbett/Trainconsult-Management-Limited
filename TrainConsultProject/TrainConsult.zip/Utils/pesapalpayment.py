import requests
import json
from . import random_id

unique_id = random_id.generate_random_string(20)

def pesa_auth():
    url = "https://pay.pesapal.com/v3/api/Auth/RequestToken"

    payload = json.dumps({
        "consumer_key": "Iitw+3sVUwH9YjsdbHV5vYb4s/YmJN1l",
        "consumer_secret": "1KnKxrGXJIFfTC1rhUxWZvjew0E="
    })
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload)

    print(response.text)

    j_response = (
        response.json()
    )

    access_token = j_response['token']

    return access_token

pesa = pesa_auth()

def reg_ipn_url():
    url = "https://pay.pesapal.com/v3/api/URLSetup/RegisterIPN"
    # pesa = pesa_auth()
    payload = json.dumps({
        "url": "https://trainconsult-management.co.ke/ipn",
        "ipn_notification_type": "GET"
    })
    headers = {
        "Authorization": "Bearer %s" % pesa,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload)

    return response

def get_ipn_list():
    url = "https://pay.pesapal.com/v3/api/URLSetup/GetIpnList"
    # pesa = pesa_auth()
    payload = {}
    headers = {
        "Authorization": "Bearer %s" % pesa,
    }

    response = requests.request("GET", url, headers=headers, data=payload)

    print(response.text)

    # return ipn_id

def submit_order_request(amount, email_address, phone_number, first_name, last_name, middle_name=""):
    url = "https://pay.pesapal.com/v3/api/Transactions/SubmitOrderRequest"
    ipn = reg_ipn_url()
    j_response = (
        ipn.json()
    )
    ipn_id = j_response['ipn_id']
    # pesa = pesa_auth()
    payload = json.dumps({
        "id": "%s" % unique_id,
        "currency": "KES",
        "amount": amount,
        "description": "Payment description goes here",
        "callback_url": "https://trainconsult-management.co.ke/events",
        "notification_id": ipn_id,
        "billing_address": {
            "email_address": email_address,
            "phone_number": phone_number,
            "country_code": "",
            "first_name": first_name,
            "middle_name": middle_name,
            "last_name": last_name,
            "line_1": "",
            "line_2": "",
            "city": "",
            "state": "",
            "postal_code": None,
            "zip_code": None
        }
    })
    headers = {
        "Authorization": "Bearer %s" % pesa,
        'Content-Type': 'application/json'
    }

    response = requests.request("POST", url, headers=headers, data=payload)

    return response

def trasaction_status():

    # res = submit_order_request()
    #
    # res_json = (
    #     res.json()
    # )
    #
    # order_tracking_id = res_json['order_tracking_id']
    # order_url = res_json['redirect_url']

    url = "https://pay.pesapal.com/v3/api/Transactions/GetOrderByTrackingId?orderTrackingId=xxxxxxxxxxxx"
    # pesa = pesa_auth()
    payload = {}
    headers = {
        "Authorization": "Bearer %s" % pesa,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }

    response = requests.request("GET", url, headers=headers, data=payload)

    return response

# print(pesa_auth())
# print(reg_ipn_url())
# get_ipn_list()
# submit = submit_order_request(1, "bettkipngenobrian@gmail.com", "0700403306")
# print(submit.text)
# trasaction_status()