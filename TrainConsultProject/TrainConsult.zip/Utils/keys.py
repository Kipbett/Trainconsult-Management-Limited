from decouple import config, Csv

business_shortCode = "174379"  # Lipa Na Mpesa Shortcode
phone_number = "254700403306"
lipa_na_mpesa_passkey = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919"
consumer_key = "zJ5GpGWoHStQYW286xhkIea71JpsbKpJ"
consumer_secret = "708GitLU1DVqjwUp"
shortcode = "174379"
# test_msisdn = config("TEST_MSISDN")

